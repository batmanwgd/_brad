<?php

/**
 * @author: VLThemes
 * @version: 1.0.1
 */

?>

<div class="vlt-page-title">

	<div class="container">

		<div class="row">

			<div class="col-md-8 offset-md-2">

				<h1><?php the_title(); ?></h1>

				<?php echo ethant_get_breadcrumbs(); ?>

			</div>

		</div>

	</div>

</div>
<!-- /.vlt-page-title -->