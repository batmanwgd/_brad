<?php

/**
 * @author: VLThemes
 * @version: 1.0.1
 */

the_post();

get_template_part( 'template-parts/single-post/single', 'post' );