<?php

/**
 * @author: VLThemes
 * @version: 1.0.1
 */

/**
 * TGM
 */
require_once ETHANT_REQUIRE_DIRECTORY . 'inc/helper/class-tgm-plugin-activation.php';

/**
 * Merlin WP
 */
require_once ETHANT_REQUIRE_DIRECTORY . 'merlin/vendor/autoload.php';
require_once ETHANT_REQUIRE_DIRECTORY . 'merlin/class-merlin.php';

/**
 * Breadcrumbs
 */
require_once ETHANT_REQUIRE_DIRECTORY . 'inc/helper/breadcrumbs/breadcrumbs.php';

/**
 * Load More
 */
require_once ETHANT_REQUIRE_DIRECTORY . 'inc/helper/load-more/load-more.php';